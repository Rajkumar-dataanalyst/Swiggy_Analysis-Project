CREATE DATABASE swiggy_dashboard_db;

USE swiggy_dashboard_db;

SELECT * FROM Customers;
SELECT * FROM CustomerAddress;
SELECT * FROM Delivery;
SELECT * FROM DeliveryAgent;
SELECT * FROM `Login Audit`;
SELECT * FROM Menu;
SELECT * FROM Orders;
SELECT * FROM Restaurant;
